package des;

public interface KeyExpansion {
    public byte[][] keyExpansion(byte[] key);
}
