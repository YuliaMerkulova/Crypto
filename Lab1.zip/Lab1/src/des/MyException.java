package des;

public class MyException extends Exception{
    public MyException(String ex){
        super(ex);
    }
}
