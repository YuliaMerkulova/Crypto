package des;

public enum ModesCipher {
    ECB,
    CBC,
    CFB,
    OFB,
    CTR,
    RD,
    RDH,
    NONE
}
